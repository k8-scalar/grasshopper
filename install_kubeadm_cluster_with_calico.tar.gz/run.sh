./install_docker.sh
./install_kubeadm_master.sh
./install_cluster.sh
